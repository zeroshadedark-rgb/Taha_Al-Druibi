IDS Prototype (MVP)
===================

Files:
- app.py             : Flask + SocketIO server that sniffs packets and emits alerts
- templates/dashboard.html : Simple dashboard that shows alerts live and a donut chart
- requirements.txt   : Python dependencies

How to run (recommended in Linux):
1) Create virtualenv:
   python3 -m venv venv
   source venv/bin/activate
2) Install:
   pip install -r requirements.txt
3) Run (live capture requires root privileges):
   sudo python3 app.py --iface eth0
   (or to replay a pcap file: python3 app.py --pcap samples/test.pcap)
4) Open browser at http://localhost:5000

Important notes:
- Only run sniffing on networks you own / have permission to monitor.
- Running live capture typically requires root/admin privileges.
- For testing you can use a pcap file by passing --pcap path_to_file.
