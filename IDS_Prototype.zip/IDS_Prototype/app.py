# app.py
from flask import Flask, render_template, send_from_directory
from flask_socketio import SocketIO, emit
from scapy.all import sniff, IP, TCP, UDP
import threading, time, collections, os, argparse

app = Flask(__name__)
app.config['SECRET_KEY'] = 'change-me'
socketio = SocketIO(app, cors_allowed_origins='*')

# In-memory alerts store (recent)
alerts = collections.deque(maxlen=500)

# Tracking state for simple rate/rule detections
syn_tracker = {}  # src -> list of timestamps for SYN packets
port_tracker = {} # src -> dict of port->last_seen timestamp

LOCK = threading.Lock()

def push_alert(alert):
    with LOCK:
        alerts.appendleft(alert)
    socketio.emit('new_alert', alert)
    print('ALERT:', alert)

def cleanup_trackers(window=60):
    now = time.time()
    for src in list(syn_tracker.keys()):
        syn_tracker[src] = [t for t in syn_tracker[src] if now - t < window]
        if not syn_tracker[src]:
            syn_tracker.pop(src, None)
    for src in list(port_tracker.keys()):
        ports = port_tracker.get(src, {})
        for p, ts in list(ports.items()):
            if now - ts > window:
                ports.pop(p, None)
        if not ports:
            port_tracker.pop(src, None)

def detect_packet(pkt):
    try:
        if IP in pkt:
            src = pkt[IP].src
            dst = pkt[IP].dst
            now = time.time()

            # TCP rules
            if TCP in pkt:
                flags = pkt[TCP].flags
                dport = int(pkt[TCP].dport)

                # Rule 1: SYN packets tracking (possible SYN flood / scan)
                if flags & 0x02:  # SYN set
                    syn_tracker.setdefault(src, []).append(now)
                    syn_count = len([t for t in syn_tracker[src] if now - t < 10])
                    if syn_count > 20:
                        push_alert({
                            'time': now,
                            'type': 'syn-flood-suspected',
                            'level': 'high',
                            'src': src,
                            'dst': dst,
                            'info': f'High SYN rate ({syn_count}) from {src}'
                        })

                # Rule 2: Port-scan detection (many distinct dst ports)
                ports = port_tracker.setdefault(src, {})
                ports[dport] = now
                distinct_ports = len(ports)
                if distinct_ports > 30:
                    push_alert({
                        'time': now,
                        'type': 'port-scan',
                        'level': 'high',
                        'src': src,
                        'dst': dst,
                        'info': f'Port scan: {distinct_ports} distinct ports from {src}'
                    })

                # Simple payload inspection
                if pkt[TCP].payload:
                    payload = bytes(pkt[TCP].payload).lower()
                    if any(x in payload for x in (b'select', b'insert', b'update', b'admin', b'exploit')):
                        push_alert({
                            'time': now,
                            'type': 'payload-suspicious',
                            'level': 'medium',
                            'src': src,
                            'dst': dst,
                            'info': f'Suspicious TCP payload to {dst}:{dport}'
                        })

            # UDP rule (uncommon port)
            if UDP in pkt:
                dport = int(pkt[UDP].dport)
                if dport not in (53, 123, 67, 68, 161):
                    push_alert({
                        'time': now,
                        'type': 'udp-to-uncommon-port',
                        'level': 'low',
                        'src': src,
                        'dst': dst,
                        'info': f'UDP to uncommon port {dport}'
                    })

    except Exception as e:
        print('detect_packet error', e)

def start_sniff(iface=None, pcap=None):
    if pcap:
        print('Replaying pcap', pcap)
        sniff(offline=pcap, prn=detect_packet, store=0)
    else:
        print('Starting live sniff on iface', iface)
        sniff(iface=iface, prn=detect_packet, store=0)

@app.route('/')
def index():
    return render_template('dashboard.html')

@app.route('/alerts.json')
def alerts_json():
    return {'alerts': list(alerts)}

@app.route('/download/ids_prototype.zip')
def download_zip():
    path = os.path.join(os.path.dirname(__file__), 'ids_prototype.zip')
    if os.path.exists(path):
        return send_from_directory(os.path.dirname(path), os.path.basename(path), as_attachment=True)
    return ('', 404)

@socketio.on('connect')
def on_connect():
    with LOCK:
        emit('recent_alerts', list(alerts)[:100])

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--iface', help='Network interface for live sniffing (requires root)', default=None)
    parser.add_argument('--pcap', help='Replay from pcap file', default=None)
    args = parser.parse_args()

    # start sniff thread
    t = threading.Thread(target=start_sniff, kwargs={'iface': args.iface, 'pcap': args.pcap}, daemon=True)
    t.start()

    # periodic cleanup thread
    def janitor():
        while True:
            cleanup_trackers()
            time.sleep(10)
    threading.Thread(target=janitor, daemon=True).start()

    socketio.run(app, host='0.0.0.0', port=5000, debug=False)
